#!/bin/bash
mvn exec:java -Dexec.mainClass="com.phoenixcorp.phoenixneon.ApiServerMain"
